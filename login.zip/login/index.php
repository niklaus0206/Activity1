<?php   
session_start(); 
if (isset($_SESSION["username"])) {
  # code...
  header('Location: success.php');
}
 ?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="newstyle.css">
</head>
<body>
<div class="form-wrapper">
  
<form method="post"> 
                     <label>Username</label> 
                     <input type="text" name="username" class="form-control" /> 
                     <br /> 
                     <label>Password</label> 
                     <input type="password" name="password" class="form-control" /> 
                     <br />  
                     <input type="submit" name="login" class="btn btn-primary btn-block" value="Login" /> 
                </form> 
  <?php
 
  ?>
  
</div>

</body>
</html>