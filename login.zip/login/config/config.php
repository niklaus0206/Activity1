<?php 
	//Database Connection
	$dbHost = "localhost";
	$dbUser = "root";
	$dbPass = "";
	$dbName = "login";

	try {
		$dbconn = new PDO("mysql:host=$dbHost;dbname=$dbName;",$dbUser,$dbPass);
	} catch (Exception $e) {
		die("Error Connection-> " . $e->getMessage());
	}
 ?>