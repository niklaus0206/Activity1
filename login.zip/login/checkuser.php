
<?php include(".\config\config.php"); ?>
<?php 
	
	extract($_POST);
	
	if(isset($btn_submit)) :
		$query = $dbconn->query("SELECT * FROM `users` WHERE username = '".$_POST['username']."' AND password = '".$_POST['password']."'");
		
		$row = $query->fetch(PDO::FETCH_ASSOC);
		if($query->rowCount() > 0) {
			session_start();
				//Set session
				$_SESSION['username'] = array(
					'id'  		=> $row[0],
					'username' 		=> $row['username'],
					'user_log' 		=> 1
					);
				
				header("location: home.php");
				} else {
					?>
					<script type="text/javascript">
						alert("Invalid Credentials");
						window.location="index.php";
					</script>
					<?php
		}

	endif;

 ?>